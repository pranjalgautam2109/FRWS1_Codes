#!/usr/bin/env python
# coding: utf-8

# In[25]:


# Factorial Function
 
val=int(input("Enter a no.  "))
fact=1
if val<0:
    print("Entered number is negative")
elif val==0:
    print("Factorial of 0 is 1")
else:
    for x in range(1,val+1):
        fact=fact*x
    print("Factorial of",val, "is", fact)


# In[83]:


# Prime or Composite

num=int(input("Enter a no."))
if num<=1:
    print("Neither prime nor composite")
elif num>1:
    for x in range(2,num):
        if(num%x==0):
            print("Number is composite")
            break
    else:
        print("number is prime ")


# In[34]:


#String Palindrome or not
strin=str(input("Enter a string: "))
if (strin==strin[::-1]):
    print("palindrome")
else:
    print("Not a palindrome")


# In[41]:


#3rd side of a right angled triangle
from math import sqrt
Side1=int(input("Enter 1st side"))
Side2=int(input("Enter 2nd side"))
Side3=sqrt(Side1*Side1+Side2*Side2)
Side3


# In[50]:


#Count each character in a string
str1=input("Enter a string:")
for x in str1:
    print("Frequency of", x,"in the string is:", str1.count(x))


# In[ ]:




